package com.bicycles;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BicyclesApplication {

	public static void main(String[] args) {
		SpringApplication.run(BicyclesApplication.class, args);
	}

}
